function numberChecking(numberOne,numberTwo){
    if(numberOne>100){
        console.log("Number 1 has many digits!")
    }
    if(numberOne<0){
        console.log("Number 1 is a negative number!")
    }
    console.log('****')
    if(numberTwo < 20){
        console.log("Number 2 is not a very high number!")
    }
    if(numberTwo > 50){
        console.log("Number 2 is a high number!")
    }
 }
 console.log(numberChecking(200,100))